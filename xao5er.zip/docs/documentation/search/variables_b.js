var searchData=
[
  ['type',['Type',['../classjson_1_1_j_s_o_n.html#a3fa6923afa41bdfe38077fbc0079aaf5',1,'json::JSON']]]
];
