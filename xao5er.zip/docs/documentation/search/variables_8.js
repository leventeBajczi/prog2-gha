var searchData=
[
  ['param1',['param1',['../class_simple_instruktion.html#a8a19958470817ee23384ac0c64fdc393',1,'SimpleInstruktion']]],
  ['param2',['param2',['../class_simple_instruktion.html#a9682f053735fffdf061ec43a989482e2',1,'SimpleInstruktion']]]
];
