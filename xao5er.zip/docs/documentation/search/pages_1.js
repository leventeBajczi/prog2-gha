var searchData=
[
  ['konzolbasiertes_20interpreter_20eines_20dynamisch_20geschriebenen_2c_20konfigurierbaren_20spraches',['Konzolbasiertes Interpreter eines dynamisch geschriebenen, konfigurierbaren Spraches',['../md_docs_spezifikation.html',1,'']]]
];
