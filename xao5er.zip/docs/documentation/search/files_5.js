var searchData=
[
  ['spezifikation_2emd',['spezifikation.md',['../spezifikation_8md.html',1,'']]],
  ['sprache_2ecpp',['sprache.cpp',['../sprache_8cpp.html',1,'']]],
  ['sprache_2ehpp',['sprache.hpp',['../sprache_8hpp.html',1,'']]]
];
