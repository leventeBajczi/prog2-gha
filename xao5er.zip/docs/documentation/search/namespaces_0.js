var searchData=
[
  ['anonymous_5fnamespace_7bjson_2ehpp_7d',['anonymous_namespace{json.hpp}',['../namespacejson_1_1anonymous__namespace_02json_8hpp_03.html',1,'json']]],
  ['json',['json',['../namespacejson.html',1,'']]]
];
