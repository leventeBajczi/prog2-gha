var searchData=
[
  ['bool',['Bool',['../unionjson_1_1_j_s_o_n_1_1_backing_data.html#a0659fafaedb7de535ae3e79e4ff4688c',1,'json::JSON::BackingData']]]
];
