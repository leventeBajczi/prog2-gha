var searchData=
[
  ['object',['object',['../classjson_1_1_j_s_o_n_1_1_j_s_o_n_wrapper.html#ab17f9cb0bc7be00173c3fdd75d2d0b73',1,'json::JSON::JSONWrapper::object()'],['../classjson_1_1_j_s_o_n_1_1_j_s_o_n_const_wrapper.html#a945ba0baef716a60327d5e4b871f9a42',1,'json::JSON::JSONConstWrapper::object()']]]
];
