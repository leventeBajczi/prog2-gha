var searchData=
[
  ['write',['write',['../class_memory.html#a0e00ea7d13e602be37af361426aa3a50',1,'Memory']]]
];
