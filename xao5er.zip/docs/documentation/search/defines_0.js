var searchData=
[
  ['language_5ffile',['LANGUAGE_FILE',['../main_8cpp.html#a9d2aadc852080725dea9477c21ff0530',1,'main.cpp']]]
];
