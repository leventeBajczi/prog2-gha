var searchData=
[
  ['generalregisterarray',['generalRegisterArray',['../class_virtual_machine.html#aae855da52e8f3b0a167b8fec497d44d9',1,'VirtualMachine']]],
  ['get',['get',['../class_j_s_o_n_object.html#ac2dd3ddb61b11a3ad800b09b41ac1562',1,'JSONObject']]],
  ['getlang',['getLang',['../class_datei.html#aeeaf8e269f4d2b53e209ad905b5b75c5',1,'Datei']]],
  ['getptr',['getPtr',['../class_virtual_machine.html#a7029636f9766e0394a8b9d60264a3565',1,'VirtualMachine']]],
  ['getreference',['getReference',['../class_virtual_machine.html#a0f55b241f2e14264dfaec5449d136a50',1,'VirtualMachine']]],
  ['getsize',['getSize',['../class_memory.html#a9687fde54e7c10c54060117045060613',1,'Memory']]],
  ['getvalue',['getValue',['../class_virtual_machine.html#a09bdaea77003f19912e0f101faefa26f',1,'VirtualMachine']]],
  ['große_20hausaufgabe_20für_20prog2',['Große Hausaufgabe für Prog2',['../index.html',1,'']]]
];
