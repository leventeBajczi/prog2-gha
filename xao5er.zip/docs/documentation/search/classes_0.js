var searchData=
[
  ['backingdata',['BackingData',['../unionjson_1_1_j_s_o_n_1_1_backing_data.html',1,'json::JSON']]]
];
