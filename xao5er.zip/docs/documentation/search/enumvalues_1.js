var searchData=
[
  ['boolean',['Boolean',['../classjson_1_1_j_s_o_n.html#a762f55df6d407c1af61607ed516ffe07a27226c864bac7454a8504f8edb15d95b',1,'json::JSON']]]
];
